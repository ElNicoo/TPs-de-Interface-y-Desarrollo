package ar.edu.centro8.desarrollo.cliente.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Clientecontroller {
     // Asegúrate de que este método esté presente para servir el formulario
    @GetMapping("/cliente")
    public String mostrarFormulario() {
        return "cliente"; // Nombre del archivo HTML
    }

    @PostMapping("/cliente/mostrar")
    public String mostrarCliente(@RequestParam("nombre") String nombre, @RequestParam("edad") int edad, Model model) {
        model.addAttribute("nombre", nombre);
        model.addAttribute("edad", edad);
        return "resultado"; // Redirige a resultado.html
    }
}
