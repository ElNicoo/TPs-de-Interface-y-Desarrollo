package ar.edu.centro8.desarrollo.odontologo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontologoApplicationTests {

	@Test
	void contextLoads() {
	}

}
