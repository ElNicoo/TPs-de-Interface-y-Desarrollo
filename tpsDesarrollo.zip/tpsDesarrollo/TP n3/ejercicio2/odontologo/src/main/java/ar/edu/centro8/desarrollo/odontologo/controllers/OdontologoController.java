package ar.edu.centro8.desarrollo.odontologo.controllers;

import ar.edu.centro8.desarrollo.odontologo.model.Paciente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class OdontologoController {
    private List<Paciente> pacientes = new ArrayList<>();

    public OdontologoController() {
        // Datos iniciales de ejemplo
        pacientes.add(new Paciente(1, "12345678", "Juan", "Pérez", LocalDate.of(2008, 5, 15)));
        pacientes.add(new Paciente(2, "87654321", "Ana", "Gómez", LocalDate.of(2005, 10, 20)));
        pacientes.add(new Paciente(3, "56781234", "Carlos", "López", LocalDate.of(1995, 3, 12)));
        pacientes.add(new Paciente(4, "43218765", "Lucía", "Fernández", LocalDate.of(2010, 1, 30)));
    }

    // Endpoint para obtener la lista completa de pacientes
    @GetMapping("/pacientes")
    public List<Paciente> obtenerPacientes() {
        return pacientes;
    }

    // Endpoint para obtener solo los pacientes menores de edad
    @GetMapping("/pacientes/menores")
    public List<Paciente> obtenerPacientesMenoresDeEdad() {
        return pacientes.stream()
                .filter(paciente -> Period.between(paciente.getFechaNacimiento(), LocalDate.now()).getYears() < 18)
                .collect(Collectors.toList());
    }
}
