package ar.edu.centro8.desarrollo.restaurante.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Plato {
    private int numero;
    private String nombre;
    private double precio;
    private String descripcion;
}
