package ar.edu.centro8.desarrollo.restaurante.controllers;

import ar.edu.centro8.desarrollo.restaurante.model.Plato;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController

public class RestauranteController {
    private List<Plato> menu = new ArrayList<>();

    public RestauranteController() {
        // Datos iniciales de ejemplo
        menu.add(new Plato(1, "Pizza Margherita", 10.5, "Pizza con tomate, mozzarella y albahaca"));
        menu.add(new Plato(2, "Pasta Carbonara", 12.0, "Pasta con panceta, huevo y queso parmesano"));
        menu.add(new Plato(3, "Ensalada César", 8.5, "Lechuga, croutones, queso y aderezo César"));
        menu.add(new Plato(4, "Sopa de Tomate", 7.0, "Sopa cremosa de tomate fresco"));
        menu.add(new Plato(5, "Hamburguesa Clásica", 9.5, "Hamburguesa con queso, lechuga y tomate"));
    }

    @GetMapping("/platos/{numero}")
    public Plato obtenerPlato(@PathVariable int numero) {
        return menu.stream()
                .filter(plato -> plato.getNumero() == numero)
                .findFirst()
                .orElse(null);
    }
}
