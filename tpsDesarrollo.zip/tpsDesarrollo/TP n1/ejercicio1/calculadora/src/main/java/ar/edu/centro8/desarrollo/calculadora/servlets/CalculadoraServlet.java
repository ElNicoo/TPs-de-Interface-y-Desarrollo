package ar.edu.centro8.desarrollo.calculadora.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CalculadoraServlet extends HttpServlet {
 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Obtener parámetros de la solicitud
        String operation = request.getParameter("operation");
        double num1 = Double.parseDouble(request.getParameter("num1"));
        double num2 = Double.parseDouble(request.getParameter("num2"));

        // Realizar la operación y mostrar el resultado
        out.println("<html><body>");
        out.println("<h1>Resultado de la operación</h1>");
        try {
            double result = 0;
            switch (operation) {
                case "add":
                    result = num1 + num2;
                    out.println("<h2>" + num1 + " + " + num2 + " = " + result + "</h2>");
                    break;
                case "subtract":
                    result = num1 - num2;
                    out.println("<h2>" + num1 + " - " + num2 + " = " + result + "</h2>");
                    break;
                case "multiply":
                    result = num1 * num2;
                    out.println("<h2>" + num1 + " * " + num2 + " = " + result + "</h2>");
                    break;
                case "divide":
                    if (num2 == 0) {
                        out.println("<h2>Error: No se puede dividir por cero</h2>");
                    } else {
                        result = num1 / num2;
                        out.println("<h2>" + num1 + " / " + num2 + " = " + result + "</h2>");
                    }
                    break;
                default:
                    out.println("<h2>Operación no válida</h2>");
            }
        } catch (Exception e) {
            out.println("<h2>Error en la operación: " + e.getMessage() + "</h2>");
        }
        out.println("<a href=\"/calculadora.html\">Volver a la calculadora</a>");
        out.println("</body></html>");
    }
}
