package ar.edu.centro8.desarrollo.calculadora.servlets;

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration

public class ServletConfig {
@Bean
    public ServletRegistrationBean<CalculadoraServlet> calculadoraServlet() {
        ServletRegistrationBean<CalculadoraServlet> servletBean = new ServletRegistrationBean<>(new CalculadoraServlet(), "/calculadora");
        servletBean.setLoadOnStartup(1);
        return servletBean;
    }
}
