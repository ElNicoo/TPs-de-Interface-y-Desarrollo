function showDiv(){
    document.getElementById("textDiv").textContent = "Ocultar Div";
    document.getElementById("hiddenText").style.display = "block";
    
}
function hideDiv(){
    document.getElementById("textDiv").textContent = "Mostrar Div";
    document.getElementById("hiddenText").style.display = "none";
}